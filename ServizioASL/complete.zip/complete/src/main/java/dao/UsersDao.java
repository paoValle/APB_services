package dao;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.SessionTrackingMode;

import model.User;
import model.User.Sesso;

public class UsersDao {

	Map<String,User> users = new HashMap<String,User>();
	
	static private UsersDao dao;
	
	static public UsersDao getInstance(){
		if(dao == null){
			dao = new UsersDao();
		}
		return dao;
	}
	
	private UsersDao() {
		users.put("GRVMHL94", new User("Michela","Gravina","03/11/1994",Sesso.valueOf("femmina"),"GRVMHL94","Giovanni Marzullo"));
		users.put("GLLNTN94", new User("Antonio","Galli","11/12/1994",Sesso.valueOf("maschio"),"GLLNTN94","Lorenzo Sodo"));
		users.put("VLLTPL94", new User("Paolo","Valletta","03/03/1994",Sesso.valueOf("maschio"),"VLLTPL94","Annamaria Liguori"));
		users.put("FRSGRG95", new User("Giorgio","Fresa","24/09/1995",Sesso.valueOf("maschio"),"FRSGRG95","Giovanna Palma"));
	}

	public User getUser(String codiceFiscale) {
		// TODO Auto-generated method stub
		return users.get(codiceFiscale);
	}

	public boolean addUser(User user) {
		// TODO Auto-generated method stub
		if(!users.containsKey(user.getCodiceFiscale())){
			users.put(user.getCodiceFiscale(),user);
			return true;		
		}else
			return false;
	}

}
