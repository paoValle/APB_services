package model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="user")
@XmlAccessorType(XmlAccessType.FIELD)
public class User implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public enum Sesso {maschio , femmina};
	
	private String	nome;
	private String	cognome; 
	private String	dataNascita;
	private Sesso 	sesso;
	private String 	codiceFiscale; 
	private String 	medicoBase;
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public User(String nome, String cognome, String dataNascita, Sesso sesso, String codiceFiscale, String medicoBase) {
		super();
		this.nome = nome;
		this.cognome = cognome;
		this.dataNascita = dataNascita;
		this.sesso = sesso;
		this.codiceFiscale = codiceFiscale;
		this.medicoBase = medicoBase;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getDataNascita() {
		return dataNascita;
	}
	public void setDataNascita(String dataNascita) {
		this.dataNascita = dataNascita;
	}
	public Sesso getSesso() {
		return sesso;
	}
	public void setSesso(Sesso sesso) {
		this.sesso = sesso;
	}
	public String getCodiceFiscale() {
		return codiceFiscale;
	}
	public void setCodiceFiscale(String codiceFiscale) {
		this.codiceFiscale = codiceFiscale;
	}
	public String getMedicoBase() {
		return medicoBase;
	}
	public void setMedicoBase(String medicoBase) {
		this.medicoBase = medicoBase;
	}
	
	
}
