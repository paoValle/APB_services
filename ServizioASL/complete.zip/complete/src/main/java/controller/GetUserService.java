package controller;


import dao.UsersDao;
import model.User;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
public class GetUserService {

	
	@GetMapping(value="/user/{codiceFiscale}")
	public User getUser(@PathVariable("codiceFiscale") String codiceFiscale){
		System.out.println("Inside get service  controller");
		UsersDao userDao = UsersDao.getInstance();
		return userDao.getUser(codiceFiscale);
	}

	
	@PostMapping(value="/user/add")
	public boolean addUser(@RequestBody User user) {
		System.out.println("Inside get service  controller");
		UsersDao userDao = UsersDao.getInstance();
		return userDao.addUser(user);

	}
	

}
