package controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import dao.UtenteDao;
import model.Utente;


@RestController
public class PagineBiancheService {

	public PagineBiancheService() {
		// TODO Auto-generated constructor stub
	}
	
	@RequestMapping(value="/utente/{cf}", produces=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.GET)
	public Utente getEmployee(@PathVariable(value="cf") String cf){
		System.out.println("Inside Pagine Bianche service controller");
		return UtenteDao.getInstance().getUtente(cf);
			
	}
	
	@RequestMapping(value="/aggiungi", produces=MediaType.APPLICATION_JSON_VALUE, method=RequestMethod.POST)
	public boolean addEmployee(@RequestBody Utente r) {
		System.out.println("Inside Pagine Bianche Addservice controller");	
		return UtenteDao.getInstance().addUtente(r);
	}
	

}
