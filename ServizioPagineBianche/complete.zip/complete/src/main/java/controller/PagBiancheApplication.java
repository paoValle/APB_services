package controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PagBiancheApplication {

	
	 public static void main(String[] args) {
	        SpringApplication.run(PagBiancheApplication.class, args);
	    }
	

}
