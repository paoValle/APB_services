package dao;

import java.util.HashMap;
import java.util.Map;

import model.Utente;


public class UtenteDao {

	static private UtenteDao dao;
	private Map<String,Utente> utenti = new HashMap<String,Utente>();
	
	static public UtenteDao getInstance(){
		if(dao == null){
			dao = new UtenteDao();
		}
		return dao;
	}
	
	private UtenteDao() {
	
		utenti.put("GRVMHL94", new Utente("GRVMHL94","Michela","Gravina","via XXV Aprile Casagiove","0823333333","3271999999","mi@.it"));
		utenti.put("GLLNTN94", new Utente("GLLNTN94","Antonio","Galli","via Euclide Napoli","0815446599","3922222222","an@.it"));
		utenti.put("VLLTPL94", new Utente("VLLTPL94","Paolo","Valletta","via Don Bosco Caserta","0823421588","3999999999","pa@.it"));
		utenti.put("RSSMRI92", new Utente("RSSMRI92","Maria","Rossi","via Quadrio Milano","0269741122","3587410258","ma@.it"));
	}
	
	public Utente getUtente(String cf) {
		return utenti.get(cf);
	}
	
	public boolean addUtente(Utente u) {
		if(utenti.containsKey(u.getCf())){
			return false;
		}
		else {
			utenti.put(u.getCf(), u);
			return true;
		}
	}

}
	
